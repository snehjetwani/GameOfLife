import java.util.Random;

class Main {
  public static void main(String[] args) {
    //Create the file for GameOfLife.java and run the unit tests. Do not write your code here.
    
    //test with 8 x 8 board; displays current and next generation
    boolean[][] board = new boolean[8][8];
    Random random = new Random();
    for(int x = 0; x<8; x++){
      for(int y = 0; y<8; y++){
        board[x][y] = random.nextBoolean();
      }
    }
    GameOfLife game = new GameOfLife(board);
    game.print();
    game.calculateNextGeneration();
    System.out.println("\nNext Gen:\n");
    game.print();
  }
}