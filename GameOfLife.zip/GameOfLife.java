public class GameOfLife{
//instance variables.
  private boolean[][] board;
  private int x;
  private int y;
  //setting up parameters of game board.
  public GameOfLife(boolean[][] board){
    if(board == null){
      this.board = new boolean[0][0];
    }else{
      this.board=board;
    }
    x = this.board.length;
    y = this.board.length;
  }
  //check to make sure cells don't go beyond bounds.
  private boolean boundChecker(int xValue, int yValue){
    if(xValue < 0 || yValue < 0 || xValue >= x || yValue >= y){
      return false;
    }else{
      return true;
    }
  }
//next cell develops depending on cell surroundings.
private boolean nextCell(int xPos, int yPos){
  int aliveNeighbours = 0;
  for(int xValue = xPos - 1; xValue <= xPos + 1; xValue++){
    for(int yValue = yPos - 1; yValue <= yPos + 1; yValue++){
      if(!boundChecker(xValue, yValue) || xValue == xPos && yValue == yPos){
        continue;
      }if(isAlive(xValue, yValue)){
        aliveNeighbours++;
        }
      }
    }
    if(aliveNeighbours == 3){
      return true;
    }else if(aliveNeighbours >= 4){
      return false;
    }else if(aliveNeighbours <= 1){
      return false;
    }else if(isAlive(xPos, yPos) && aliveNeighbours == 2){
      return true;
    }else{
      return false;
    }
  }
  //calculate the next generation of the universe.
  public void calculateNextGeneration(){
    boolean[][] nextGenArray = new boolean[x][y];
    for(int xValue = 0; xValue < x; xValue++){
      for (int yValue = 0; yValue < y; yValue++){
        nextGenArray[xValue][yValue] = nextCell(xValue, yValue);
      }
    }
    this.board = nextGenArray;
  }
  //prints the current generation to the console.
  public void print(){
    for(int xValue = 0; xValue < x; xValue++){
      for(int yValue = 0; yValue < y; yValue++){
        if(isAlive(xValue,yValue)){
          System.out.print("*");
        }else{
          System.out.print(".");
        }
      }
      System.out.println();
    }
  }
  //sets whether the cell at (x,y) is alive.
  public void setAlive(int x, int y, boolean isAlive){
    if(boundChecker(x, y)){
      board[x][y] = isAlive;
    }
  }
  //returns whether the cell at (x,y) is alive
  public boolean isAlive(int x, int y){
    if(boundChecker(x, y)){
      return board[x][y];
    }else{
      return false;
    }
  }
}