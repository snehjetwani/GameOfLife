# Introduction
For this assignment, you will implement a simple version of the Game of Life.

# Assignment
![Instructions](Instructions1.jpg)
![Instructions](Instructions2.jpg)
![Instructions](Instructions3.jpg)

## Specification
Your "universe" should be a square two-dimensional grid. Implement this as a two-dimensional array of n x n elements of type boolean
- Create a class GameOfLife with the following public methods:
  - public GameOfLife(boolean[][] board) //constructor
  - public void calculateNextGeneration()  //calculate the next generation of the universe.
  - public void print() //prints the current generation to the console using '*' for cells that are alive and '.' for cells that are not.
  - public void setAlive(int x, int y, boolean isAlive) //sets whether the cell at (x,y) is alive;
  - public boolean isAlive(int x, int y) //returns whether the cell at (x,y) is alive; (0,0) is at the top left
- Use the unit test to ensure your code is correct.
  - Bounds checking is very important here, as it always is when working with arrays.
  - Don't rely on try/catch blocks to trap out of bounds exceptions. They are entirely preventable!
- Consider how efficiently you are using memory. Are you continuously declaring new arrays? Hint: you should not.
- Challenges:
  - Add a method that checks whether your universe has become static (i.e. stable, not changing)
  - Make your universe circular by allowing objects that travel off the right hand side of the grid to reappear on the left hand side and vice versa. (i.e. element [0][0] is "to the right" of element [49][0],  element[49][10] is "above" element [0][10] etc)
